<?php
  phpinfo();
?>
